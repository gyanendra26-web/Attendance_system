<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
requireLogin();

if (!isAdmin()) {
    header("Location: ../login.php");
    exit();
}

$message = '';

// Add new holiday
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_holiday'])) {
    $holiday_name = sanitize($_POST['holiday_name']);
    $holiday_date = sanitize($_POST['holiday_date']);
    $holiday_type = sanitize($_POST['holiday_type']);
    $description = sanitize($_POST['description']);
    
    $query = "INSERT INTO holidays (holiday_name, holiday_date, holiday_type, description) 
              VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ssss", $holiday_name, $holiday_date, 
                         $holiday_type, $description);
    
    if (mysqli_stmt_execute($stmt)) {
        $message = '<div class="alert success">Holiday added successfully!</div>';
    } else {
        $message = '<div class="alert error">Error adding holiday!</div>';
    }
}

// Delete holiday
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $query = "DELETE FROM holidays WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    
    header("Location: holidays.php");
    exit();
}

// Get all holidays
$query = "SELECT * FROM holidays 
          WHERE YEAR(holiday_date) >= YEAR(CURDATE()) 
          ORDER BY holiday_date";
$holidays = mysqli_query($conn, $query);

// Get Nepali festivals for next year
$nepali_festivals = [
    ['Maha Shivaratri', '2024-03-08', 'festival', 'Maha Shivaratri'],
    ['Holi', '2024-03-25', 'festival', 'Festival of Colors'],
    ['Buddha Jayanti', '2024-05-23', 'national', 'Birthday of Lord Buddha'],
    ['Dashain Start', '2024-10-10', 'festival', 'Ghatasthapana'],
    ['Fulpati', '2024-10-15', 'festival', 'Fulpati'],
    ['Maha Asthami', '2024-10-16', 'festival', 'Maha Asthami'],
    ['Maha Navami', '2024-10-17', 'festival', 'Maha Navami'],
    ['Vijaya Dashami', '2024-10-18', 'festival', 'Vijaya Dashami'],
    ['Tihar Start', '2024-11-01', 'festival', 'Kaag Tihar'],
    ['Laxmi Puja', '2024-11-03', 'festival', 'Laxmi Puja'],
    ['Gobardhan Puja', '2024-11-04', 'festival', 'Gobardhan Puja'],
    ['Bhai Tika', '2024-11-05', 'festival', 'Bhai Tika'],
    ['Chhath', '2024-11-07', 'festival', 'Chhath Parva'],
    ['Christmas', '2024-12-25', 'national', 'Christmas Day']
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Holiday Management</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <div class="dashboard-grid">
            <?php include 'sidebar.php'; ?>
            
            <main class="main-content">
                <h2>Holiday Management</h2>
                
                <?php echo $message; ?>
                
                <div class="card">
                    <h3>Add New Holiday</h3>
                    <form method="POST" action="">
                        <div class="form-row">
                            <div class="form-group">
                                <label>Holiday Name</label>
                                <input type="text" name="holiday_name" required>
                            </div>
                            
                            <div class="form-group">
                                <label>Date</label>
                                <input type="date" name="holiday_date" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Type</label>
                                <select name="holiday_type" required>
                                    <option value="national">National Holiday</option>
                                    <option value="festival">Festival</option>
                                    <option value="weekly">Weekly (Saturday)</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>Description</label>
                                <input type="text" name="description">
                            </div>
                        </div>
                        
                        <button type="submit" name="add_holiday" class="btn btn-primary">
                            Add Holiday
                        </button>
                    </form>
                </div>
                
                <!-- Quick Add Nepali Festivals -->
                <div class="card">
                    <h3>Quick Add: Nepali Festivals 2024</h3>
                    <div class="festival-grid">
                        <?php foreach ($nepali_festivals as $festival): ?>
                        <div class="festival-item">
                            <span><?php echo $festival[0]; ?></span>
                            <span><?php echo date('M d', strtotime($festival[1])); ?></span>
                            <form method="POST" action="" style="display:inline;">
                                <input type="hidden" name="holiday_name" value="<?php echo $festival[0]; ?>">
                                <input type="hidden" name="holiday_date" value="<?php echo $festival[1]; ?>">
                                <input type="hidden" name="holiday_type" value="<?php echo $festival[2]; ?>">
                                <input type="hidden" name="description" value="<?php echo $festival[3]; ?>">
                                <button type="submit" name="add_holiday" class="btn btn-sm btn-success">
                                    Add
                                </button>
                            </form>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Holiday List -->
                <div class="card">
                    <h3>Upcoming Holidays</h3>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Holiday Name</th>
                                    <th>Type</th>
                                    <th>Description</th>
                                    <th>Day</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($holiday = mysqli_fetch_assoc($holidays)): ?>
                                <tr>
                                    <td><?php echo date('Y-m-d', strtotime($holiday['holiday_date'])); ?></td>
                                    <td><?php echo $holiday['holiday_name']; ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $holiday['holiday_type']; ?>">
                                            <?php echo ucfirst($holiday['holiday_type']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo $holiday['description']; ?></td>
                                    <td><?php echo date('l', strtotime($holiday['holiday_date'])); ?></td>
                                    <td>
                                        <a href="?delete=<?php echo $holiday['id']; ?>" 
                                           class="btn btn-danger btn-sm"
                                           onclick="return confirm('Delete this holiday?')">
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    </div>
</body>
</html>